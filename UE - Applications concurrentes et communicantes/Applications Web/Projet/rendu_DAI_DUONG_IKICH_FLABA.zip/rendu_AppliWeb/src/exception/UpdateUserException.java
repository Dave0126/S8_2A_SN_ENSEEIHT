package exception;

/**
 * @ClassName: UpdateUserException
 * @Description: TODO
 * @author: Guohao
 * @Version: 1.0
 **/
public class UpdateUserException extends Exception {
    public UpdateUserException() {
        super();
        // TODO Auto-generated constructor stub
    }

    public UpdateUserException(String message, Throwable cause) {
        super(message, cause);
        // TODO Auto-generated constructor stub
    }

    public UpdateUserException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

    public UpdateUserException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }
}
