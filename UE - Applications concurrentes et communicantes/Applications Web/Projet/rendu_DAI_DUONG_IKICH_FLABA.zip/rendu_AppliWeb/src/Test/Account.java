package Test;

/**
 * @ClassName: Account
 * @Description: TODO
 * @author: Guohao
 * @version: V1.0
 **/

public class Account {
    private int cardid;
    private String name;
    private int account;

    public int getCardid() {
        return cardid;
    }

    public void setCardid(int cardid) {
        this.cardid = cardid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAccount() {
        return account;
    }

    public void setAccount(int account) {
        this.account = account;
    }
}
