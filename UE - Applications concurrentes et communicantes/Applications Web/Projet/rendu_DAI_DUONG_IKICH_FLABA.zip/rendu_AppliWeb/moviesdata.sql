/*
 Navicat Premium Data Transfer

 Source Server         : 本地MySQL数据库
 Source Server Type    : MySQL
 Source Server Version : 80028
 Source Host           : localhost:3306
 Source Schema         : moviesdata

 Target Server Type    : MySQL
 Target Server Version : 80028
 File Encoding         : 65001

 Date: 01/06/2022 16:00:19
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for allmovies
-- ----------------------------
DROP TABLE IF EXISTS `allmovies`;
CREATE TABLE `allmovies` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '电影id',
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '电影名字',
  `score` int DEFAULT NULL COMMENT '电影评分',
  `director` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '导演',
  `scriptwriter` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '编剧',
  `actor` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '演员',
  `years` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '上映日期',
  `country` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '国家',
  `languages` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '语言',
  `length` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '片长',
  `image` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '电影图片地址',
  `des` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '电影简介',
  `url` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '电影播放地址',
  `type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '电影类型',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=945 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of allmovies
-- ----------------------------
BEGIN;
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (1, 'test_ani_10', 10, 'gdai', 'gdai', 'gdai', '2022', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Animation');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (2, 'test_mystery_10', 10, 'gdai', 'gdai', 'gdai', '2021', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Mystery');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (3, 'test_adv_10', 10, 'gdai', 'gdai', 'gdai', '2020', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Adventure');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (4, 'test_hor_10', 10, 'gdai', 'gdai', 'gdai', '2022', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Horror');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (5, 'test_sci_10', 10, 'gdai', 'gdai', 'gdai', '2021', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'SCI_FI');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (6, 'test_dra_10', 10, 'gdai', 'gdai', 'gdai', '2020', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Drama');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (7, 'test_thr_10', 10, 'gdai', 'gdai', 'gdai', '2021', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Thriller');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (8, 'test_cri_10', 10, 'gdai', 'gdai', 'gdai', '2021', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Crime');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (9, 'test_act_10', 10, 'gdai', 'gdai', 'gdai', '2021', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Action');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (10, 'test_fan_10', 10, 'gdai', 'gdai', 'gdai', '2003', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Fantasy');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (11, 'test_com_10', 10, 'gdai', 'gdai', 'gdai', '2020', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Comedy');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (12, 'test_ani_8', 8, 'gdai', 'gdai', 'gdai', '2010', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Animation');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (13, 'test_ani_5', 5, 'gdai', 'gdai', 'gdai', '1999', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Animation');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (14, 'test_mystery_5', 5, 'gdai', 'gdai', 'gdai', '2018', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Mystery');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (15, 'test_adv_5', 5, 'gdai', 'gdai', 'gdai', '2017', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Adventure');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (16, 'test_hor_5', 5, 'gdai', 'gdai', 'gdai', '2000', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Horror');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (17, 'test_sci_5', 5, 'gdai', 'gdai', 'gdai', '2000', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'SCI_FI');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (18, 'test_dra_5', 5, 'gdai', 'gdai', 'gdai', '2012', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Drama');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (19, 'test_thr_5', 5, 'gdai', 'gdai', 'gdai', '2022', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Thriller');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (20, 'test_cri_5', 5, 'gdai', 'gdai', 'gdai', '2022', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Crime');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (21, 'test_act_5', 5, 'gdai', 'gdai', 'gdai', '2022', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Action');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (22, 'test_fan_5', 5, 'gdai', 'gdai', 'gdai', '2022', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Fantasy');
INSERT INTO `allmovies` (`id`, `name`, `score`, `director`, `scriptwriter`, `actor`, `years`, `country`, `languages`, `length`, `image`, `des`, `url`, `type`) VALUES (23, 'test_com_5', 5, 'gdai', 'gdai', 'gdai', '2022', ' 中国大陆', ' CN', '110 mins', 'donghua//1.jpg', '\n Test for demo. \n', 'https://www.imdb.com/', 'Comedy');
COMMIT;

-- ----------------------------
-- Table structure for clicknumber
-- ----------------------------
DROP TABLE IF EXISTS `clicknumber`;
CREATE TABLE `clicknumber` (
  `movieName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '电影名',
  `number` int DEFAULT '1' COMMENT '电影被点击的次数',
  PRIMARY KEY (`movieName`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of clicknumber
-- ----------------------------
BEGIN;
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_act_10', 14);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_act_5', 23);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_adv_10', 21);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_adv_5', 56);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_ani_10', 75);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_ani_5', 43);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_ani_8', 55);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_cri_10', 66);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_cri_5', 77);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_dra_10', 645);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_dra_5', 65);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_hor_10', 78);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_hor_5', 56);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_mystery_10', 78);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_mystery_5', 9);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_sci_10', 32);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_sci_5', 89);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_thr_10', 67);
INSERT INTO `clicknumber` (`movieName`, `number`) VALUES ('test_thr_5', 104);
COMMIT;

-- ----------------------------
-- Table structure for collection
-- ----------------------------
DROP TABLE IF EXISTS `collection`;
CREATE TABLE `collection` (
  `userName` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户ID',
  `movieName` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '电影ID',
  `addTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`userName`,`movieName`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of collection
-- ----------------------------
BEGIN;
INSERT INTO `collection` (`userName`, `movieName`, `addTime`) VALUES ('', 'test_dra_5', '2022-06-01 15:51:09');
INSERT INTO `collection` (`userName`, `movieName`, `addTime`) VALUES ('gdai', 'test_com_10', '2022-06-01 15:48:36');
INSERT INTO `collection` (`userName`, `movieName`, `addTime`) VALUES ('gdai', 'test_com_5', '2022-06-01 15:48:38');
COMMIT;

-- ----------------------------
-- Table structure for comments
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `userName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '用户ID',
  `movieName` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '电影ID',
  `description` varchar(250) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'null' COMMENT '用户对电影的评论',
  `addTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '添加评论的时间\r\n'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of comments
-- ----------------------------
BEGIN;
INSERT INTO `comments` (`userName`, `movieName`, `description`, `addTime`) VALUES ('admin', 'test_ani_10', 'test', '2022-05-20 14:38:17');
INSERT INTO `comments` (`userName`, `movieName`, `description`, `addTime`) VALUES ('gdai', 'test_ani_10', 'test', '2022-05-20 14:38:17');
INSERT INTO `comments` (`userName`, `movieName`, `description`, `addTime`) VALUES ('admin', 'test_ani_5', 'test', '2022-05-20 14:38:17');
INSERT INTO `comments` (`userName`, `movieName`, `description`, `addTime`) VALUES ('gdai', 'test_ani_5', 'test', '2022-05-20 14:38:17');
INSERT INTO `comments` (`userName`, `movieName`, `description`, `addTime`) VALUES ('admin', 'test_dra_5', 'test[微笑]', '2022-06-01 15:51:00');
COMMIT;

-- ----------------------------
-- Table structure for history
-- ----------------------------
DROP TABLE IF EXISTS `history`;
CREATE TABLE `history` (
  `movieName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '电影名',
  `userid` int NOT NULL,
  `addTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`movieName`,`userid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of history
-- ----------------------------
BEGIN;
INSERT INTO `history` (`movieName`, `userid`, `addTime`) VALUES ('test_act_5', 1, '2022-06-01 15:50:34');
INSERT INTO `history` (`movieName`, `userid`, `addTime`) VALUES ('test_com_5', 2, '2022-06-01 15:48:30');
INSERT INTO `history` (`movieName`, `userid`, `addTime`) VALUES ('test_dra_5', 1, '2022-06-01 15:50:47');
COMMIT;

-- ----------------------------
-- Table structure for score
-- ----------------------------
DROP TABLE IF EXISTS `score`;
CREATE TABLE `score` (
  `movieid` int NOT NULL COMMENT '电影id，关联movies表中的主键',
  `userid` int NOT NULL COMMENT '用户id，关联users表中的主键',
  `score` int DEFAULT NULL COMMENT '用户对电影的评分',
  PRIMARY KEY (`movieid`,`userid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of score
-- ----------------------------
BEGIN;
INSERT INTO `score` (`movieid`, `userid`, `score`) VALUES (1, 1, 10);
COMMIT;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '系统自动编号，自增',
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'null' COMMENT '用户名称',
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'null' COMMENT '用户密码',
  `gender` varchar(4) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'null' COMMENT '用户性别',
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'null' COMMENT '用户邮箱',
  `telephone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'null' COMMENT '用户电话',
  `introduce` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '这家伙很懒，还没有添加任何描述' COMMENT '自我介绍',
  `activeCode` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'null' COMMENT '注册激活码',
  `state` int DEFAULT '1' COMMENT '用户状态：1:激活 0：未激活',
  `role` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT 'commonUser' COMMENT '用户角色：普通用户，超级用户，VIP用户',
  `registTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '注册时间',
  PRIMARY KEY (`id`,`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` (`id`, `username`, `password`, `gender`, `email`, `telephone`, `introduce`, `activeCode`, `state`, `role`, `registTime`) VALUES (1, 'admin', '123456', 'Male', 'gdai@n7.fr', '18770411594', '管理员', '1024', 1, 'admin', '2022-06-01 13:22:56');
INSERT INTO `users` (`id`, `username`, `password`, `gender`, `email`, `telephone`, `introduce`, `activeCode`, `state`, `role`, `registTime`) VALUES (2, 'gdai', '1111', 'null', 'gdai@n7.fr', 'null', 'A international student in N7', 'null', 1, 'commonUser', '2022-05-20 15:58:17');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
