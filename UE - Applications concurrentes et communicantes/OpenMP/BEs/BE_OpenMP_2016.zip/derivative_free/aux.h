long usecs ();
double evaluate(double x, double y);
void mysleep(double sec);
