long usecs ();
int func();
void mysleep(double sec);

