#!/bin/bash

export LBLAS="/mnt/n7fs/ens/tp_abuttari/acml-4.4.0/gfortran64/lib/libacml.a -lgfortran -lm"
# export PATH=/mnt/n7fs/ens/tp_abuttari/opt/gcc_trunk/bin/:$PATH;
# export LD_LIBRARY_PATH=/mnt/n7fs/ens/tp_abuttari/opt/gmp-4.3.2/lib/:$LD_LIBRARY_PATH
# export LD_LIBRARY_PATH=/mnt/n7fs/ens/tp_abuttari/opt/mpfr-2.4.2/lib/:$LD_LIBRARY_PATH
# export LD_LIBRARY_PATH=/mnt/n7fs/ens/tp_abuttari/opt/mpc-0.8.1/lib/:$LD_LIBRARY_PATH
# export LD_LIBRARY_PATH=/mnt/n7fs/ens/tp_abuttari/opt/isl-0.12.2/lib/:$LD_LIBRARY_PATH
# export LD_LIBRARY_PATH=/mnt/n7fs/ens/tp_abuttari/opt/gcc_trunk/lib64/:$LD_LIBRARY_PATH
