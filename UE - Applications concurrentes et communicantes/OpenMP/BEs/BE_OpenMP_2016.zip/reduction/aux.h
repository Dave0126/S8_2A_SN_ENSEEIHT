long usecs ();
void operator(int *a, int *b);
void mysleep(double sec);
